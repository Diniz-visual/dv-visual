<?php
/**
 * Portfolio landing page.
 *
 * CONTENT: projects come from Portfólio, filters from Segmentos and hero copy
 * from this page's "DV Visual — Hero e SEO" fields.
 *
 * @package DinizStudio
 */
echo diniz_studio_portfolio_archive_shortcode(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
