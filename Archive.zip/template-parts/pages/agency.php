<?php
/**
 * Estúdio page composition.
 *
 * @package DinizStudio
 */
?>
<main id="dv-main-content">
	<?php diniz_studio_render_pattern( 'performance-hero' ); ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php if ( trim( get_the_content() ) ) : ?><section class="dv-page-editor-content"><?php the_content(); ?></section><?php endif; ?>
	<?php endwhile; ?>
	<section class="dv-page-collections">
		<?php echo diniz_studio_cpt_featured_shortcode( array( 'post_type' => 'team', 'limit' => 4, 'kicker' => 'Nosso time', 'title' => 'Talentos diferentes. Uma mesma intenção.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo diniz_studio_cpt_featured_shortcode( array( 'post_type' => 'award', 'limit' => 3, 'kicker' => 'Reconhecimento', 'title' => 'Trabalho que ganha espaço e relevância.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo diniz_studio_cpt_featured_shortcode( array( 'post_type' => 'job', 'limit' => 3, 'kicker' => 'Faça parte', 'title' => 'Próximas oportunidades no estúdio.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</section>
	<?php diniz_studio_render_pattern( 'results' ); ?>
	<?php diniz_studio_render_pattern( 'process' ); ?>
	<?php diniz_studio_render_pattern( 'cta' ); ?>
</main>
