<?php
/** Blank page canvas. @package DinizStudio */
?>
<main id="dv-main-content" class="dv-blank-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>><?php the_content(); ?></article>
	<?php endwhile; ?>
</main>
