<?php
/**
 * Frequently asked questions.
 *
 * PANEL: every question and answer is editable as blocks in Home — Seções.
 *
 * @package DinizStudio
 */
$section_id = ! empty( $args['section_id'] ) ? (int) $args['section_id'] : 0;
diniz_studio_render_managed_home_section( $section_id, 'faq' );
