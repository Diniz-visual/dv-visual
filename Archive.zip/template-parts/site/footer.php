<?php
/**
 * Five-column, widget-ready global footer.
 *
 * Every column has a native WordPress widget area. Curated fallbacks keep the
 * footer complete until the administrator adds widgets in Appearance >
 * Widgets.
 *
 * @package DinizStudio
 */

$description = diniz_studio_content_field( 'company_description', 'option' ) ?: __( 'Marcas fortes começam com clareza. Transformamos estratégia em uma presença visual relevante, consistente e memorável.', 'dv-visual' );
$email       = diniz_studio_content_field( 'company_email', 'option' ) ?: get_option( 'admin_email' );
$phone       = diniz_studio_content_field( 'company_phone', 'option' );
$hours       = diniz_studio_content_field( 'company_hours', 'option' );
$address     = diniz_studio_content_field( 'company_address', 'option' );
$light_logo  = diniz_studio_content_field( 'brand_logo_light', 'option' );
$year        = wp_date( 'Y' );
$blog_page   = (int) get_option( 'page_for_posts' );
$blog_url    = $blog_page ? get_permalink( $blog_page ) : home_url( '/blog/' );
$services    = get_posts(
	array(
		'post_type'      => 'service',
		'post_status'    => 'publish',
		'posts_per_page' => 7,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
	)
);
$guides      = get_posts(
	array(
		'post_type'      => 'guide',
		'post_status'    => 'publish',
		'posts_per_page' => 3,
		'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
	)
);
$categories  = get_categories(
	array(
		'hide_empty' => true,
		'number'     => 5,
		'orderby'    => 'count',
		'order'      => 'DESC',
	)
);
?>
<footer class="dv-footer dv-footer--global alignfull has-white-color has-ink-background-color has-text-color has-background">
	<div class="dv-footer__shell">
		<div class="dv-footer__grid">
			<div class="dv-footer__column dv-footer__column--brand">
				<div class="dv-footer-brand">
					<?php
					if ( $light_logo ) {
						?>
						<a class="dv-footer-brand__link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php echo diniz_studio_acf_image( $light_logo, 'full', 'dv-footer-brand__image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
						<?php
					} elseif ( has_custom_logo() ) {
						the_custom_logo();
					} else {
						?>
						<a class="dv-footer-brand__name" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
						<?php
					}
					?>
				</div>
				<p class="dv-footer__description"><?php echo esc_html( $description ); ?></p>
				<div class="dv-footer__contact">
					<?php if ( $phone ) : ?><p><small><?php esc_html_e( 'Telefone / WhatsApp:', 'dv-visual' ); ?></small><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p><?php endif; ?>
					<?php if ( $email ) : ?><p><small><?php esc_html_e( 'E-mail:', 'dv-visual' ); ?></small><a href="<?php echo esc_url( 'mailto:' . sanitize_email( $email ) ); ?>"><?php echo esc_html( antispambot( $email ) ); ?></a></p><?php endif; ?>
					<?php if ( $hours ) : ?><p><small><?php esc_html_e( 'Atendimento:', 'dv-visual' ); ?></small><span><?php echo esc_html( $hours ); ?></span></p><?php endif; ?>
					<?php if ( $address ) : ?><p><small><?php esc_html_e( 'Endereço:', 'dv-visual' ); ?></small><span><?php echo nl2br( esc_html( $address ) ); ?></span></p><?php endif; ?>
				</div>
				<?php if ( is_active_sidebar( 'dv-footer-brand' ) ) : ?>
					<div class="dv-footer__widgets"><?php dynamic_sidebar( 'dv-footer-brand' ); ?></div>
				<?php endif; ?>
				<div class="dv-footer-social">
					<?php echo diniz_studio_menu_block( array( 'location' => 'social' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>

			<div class="dv-footer__column">
				<?php if ( is_active_sidebar( 'dv-footer-solutions' ) ) : ?>
					<?php dynamic_sidebar( 'dv-footer-solutions' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Soluções', 'dv-visual' ); ?></h3>
					<ul class="dv-footer__links">
						<?php foreach ( $services as $service ) : ?><li><a href="<?php echo esc_url( get_permalink( $service ) ); ?>"><?php echo esc_html( get_the_title( $service ) ); ?></a></li><?php endforeach; ?>
					</ul>
					<a class="dv-footer__more" href="<?php echo esc_url( get_post_type_archive_link( 'service' ) ); ?>"><?php esc_html_e( 'Ver todas', 'dv-visual' ); ?> <span aria-hidden="true">→</span></a>
				<?php endif; ?>
			</div>

			<div class="dv-footer__column">
				<?php if ( is_active_sidebar( 'dv-footer-content' ) ) : ?>
					<?php dynamic_sidebar( 'dv-footer-content' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Blog & conteúdo', 'dv-visual' ); ?></h3>
					<ul class="dv-footer__links">
						<?php if ( $categories ) : ?>
							<?php foreach ( $categories as $category ) : ?><li><a href="<?php echo esc_url( get_category_link( $category ) ); ?>"><?php echo esc_html( $category->name ); ?></a></li><?php endforeach; ?>
						<?php else : ?>
							<li><a href="<?php echo esc_url( $blog_url ); ?>"><?php esc_html_e( 'Estratégia de marca', 'dv-visual' ); ?></a></li>
							<li><a href="<?php echo esc_url( $blog_url ); ?>"><?php esc_html_e( 'Design e identidade', 'dv-visual' ); ?></a></li>
							<li><a href="<?php echo esc_url( $blog_url ); ?>"><?php esc_html_e( 'Sites e produtos digitais', 'dv-visual' ); ?></a></li>
						<?php endif; ?>
					</ul>
					<a class="dv-footer__more" href="<?php echo esc_url( $blog_url ); ?>"><?php esc_html_e( 'Todos os artigos', 'dv-visual' ); ?> <span aria-hidden="true">→</span></a>
				<?php endif; ?>
			</div>

			<div class="dv-footer__column">
				<?php if ( is_active_sidebar( 'dv-footer-guides' ) ) : ?>
					<?php dynamic_sidebar( 'dv-footer-guides' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Guias completos', 'dv-visual' ); ?></h3>
					<ul class="dv-footer__links">
						<?php if ( $guides ) : ?>
							<?php foreach ( $guides as $guide ) : ?><li><a href="<?php echo esc_url( get_permalink( $guide ) ); ?>"><?php echo esc_html( get_the_title( $guide ) ); ?></a></li><?php endforeach; ?>
						<?php else : ?>
							<li><a href="<?php echo esc_url( get_post_type_archive_link( 'guide' ) ); ?>"><?php esc_html_e( 'Identidade visual', 'dv-visual' ); ?></a></li>
							<li><a href="<?php echo esc_url( get_post_type_archive_link( 'guide' ) ); ?>"><?php esc_html_e( 'Comunicação digital', 'dv-visual' ); ?></a></li>
							<li><a href="<?php echo esc_url( get_post_type_archive_link( 'guide' ) ); ?>"><?php esc_html_e( 'Presença de marca', 'dv-visual' ); ?></a></li>
						<?php endif; ?>
					</ul>
					<a class="dv-footer__more" href="<?php echo esc_url( get_post_type_archive_link( 'guide' ) ); ?>"><?php esc_html_e( 'Todos os guias', 'dv-visual' ); ?> <span aria-hidden="true">→</span></a>
				<?php endif; ?>
			</div>

			<div class="dv-footer__column">
				<?php if ( is_active_sidebar( 'dv-footer-institutional' ) ) : ?>
					<?php dynamic_sidebar( 'dv-footer-institutional' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Institucional', 'dv-visual' ); ?></h3>
					<?php echo diniz_studio_menu_block( array( 'location' => 'footer' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<a class="dv-footer__more" href="<?php echo esc_url( diniz_studio_menu_page_url( 'proposta' ) ); ?>"><?php esc_html_e( 'Solicitar proposta', 'dv-visual' ); ?> <span aria-hidden="true">→</span></a>
				<?php endif; ?>
			</div>
		</div>

		<div class="dv-footer__bottom">
			<?php if ( is_active_sidebar( 'dv-footer-bottom' ) ) : ?>
				<?php dynamic_sidebar( 'dv-footer-bottom' ); ?>
			<?php else : ?>
				<p>© <?php echo esc_html( $year ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'Todos os direitos reservados.', 'dv-visual' ); ?></p>
				<p><a href="<?php echo esc_url( diniz_studio_menu_page_url( 'privacidade' ) ); ?>"><?php esc_html_e( 'Privacidade', 'dv-visual' ); ?></a> · <a href="<?php echo esc_url( diniz_studio_menu_page_url( 'termos' ) ); ?>"><?php esc_html_e( 'Termos', 'dv-visual' ); ?></a></p>
			<?php endif; ?>
		</div>
	</div>
</footer>
