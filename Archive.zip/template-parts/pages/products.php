<?php
/** Products landing page. @package DinizStudio */
?>
<main id="dv-main-content">
	<?php while ( have_posts() ) : the_post(); ?>
		<section class="wp-block-group alignfull dv-page-hero"><div class="wp-block-group alignwide"><p class="dv-kicker dv-kicker-dark"><?php esc_html_e( 'Produtos DV', 'dv-visual' ); ?></p><h1 class="has-xxl-font-size"><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p class="has-l-font-size"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?></div></section>
		<?php if ( trim( get_the_content() ) ) : ?><section class="dv-page-editor-content"><?php the_content(); ?></section><?php endif; ?>
	<?php endwhile; ?>
	<section class="dv-page-collections">
		<?php echo diniz_studio_cpt_featured_shortcode( array( 'post_type' => 'product', 'limit' => 6, 'kicker' => 'Produtos DV', 'title' => 'Soluções prontas para sua próxima fase.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</section>
	<?php diniz_studio_render_pattern( 'cta' ); ?>
</main>
