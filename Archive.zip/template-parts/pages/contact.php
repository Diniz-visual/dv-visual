<?php
/** Contact page. @package DinizStudio */
?>
<main id="dv-main-content" class="wp-block-group dv-contact-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<div class="wp-block-columns alignwide">
			<div class="wp-block-column">
				<p class="dv-kicker"><?php esc_html_e( 'Vamos conversar', 'dv-visual' ); ?></p>
				<h1><?php the_title(); ?></h1>
				<p><?php esc_html_e( 'Conte um pouco sobre sua empresa, seus desafios e objetivos. Retornaremos com os próximos passos.', 'dv-visual' ); ?></p>
			</div>
			<div class="wp-block-column dv-card">
				<div class="wp-block-post-content"><?php the_content(); ?></div>
				<?php if ( ! trim( get_the_content() ) && current_user_can( 'edit_post', get_the_ID() ) ) : ?>
					<p><strong><?php esc_html_e( 'Adicione aqui seu formulário preferido.', 'dv-visual' ); ?></strong></p>
					<p><?php esc_html_e( 'Compatível com Contact Form 7, WPForms, Fluent Forms e formulários nativos.', 'dv-visual' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	<?php endwhile; ?>
</main>
