<?php
/**
 * Complete, panel-managed Home.
 *
 * PANEL:
 * - Home — Seções: order, visibility and block content of every section.
 * - Home — Slides: complete slides shown by the Hero Swiper.
 *
 * CODE:
 * - Each section renderer lives in template-parts/home/{section-key}.php.
 * - The fallback list below is only used before the initial automatic setup.
 * - Data-driven cards keep coming from their own Custom Post Types.
 *
 * @package DinizStudio
 */

$managed_sections = function_exists( 'diniz_studio_get_managed_home_sections' )
	? diniz_studio_get_managed_home_sections()
	: array();

/*
 * Safe first-run fallback. After theme activation, this order is controlled by
 * the "Order" field inside Home — Seções and no code movement is necessary.
 */
$fallback_sections = array(
	'hero',
	'client-trust',
	'problems',
	'solution-ecosystem',
	'manifesto',
	'portfolio-showcase',
	'content-hub',
	'softwares',
	'process',
	'testimonials',
	'faq',
	'posts-grid',
	'cta',
);
?>
<main id="dv-main-content" class="dv-home-main">
	<?php if ( $managed_sections ) : ?>
		<?php foreach ( $managed_sections as $managed_section ) : ?>
			<?php
			$enabled = (bool) diniz_studio_managed_field( $managed_section->ID, 'dv_home_section_enabled', 1 );
			if ( ! $enabled ) {
				continue;
			}

			$section_key  = sanitize_file_name( (string) diniz_studio_managed_field( $managed_section->ID, 'dv_home_section_key', 'custom' ) );
			$template     = locate_template( 'template-parts/home/' . $section_key . '.php', false, false );
			$section_part = $template ? $section_key : 'custom';

			get_template_part(
				'template-parts/home/' . $section_part,
				null,
				array( 'section_id' => $managed_section->ID )
			);
			?>
		<?php endforeach; ?>
	<?php else : ?>
		<?php foreach ( $fallback_sections as $section_part ) : ?>
			<?php get_template_part( 'template-parts/home/' . $section_part ); ?>
		<?php endforeach; ?>
	<?php endif; ?>
</main>
