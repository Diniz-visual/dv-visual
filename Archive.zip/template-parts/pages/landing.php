<?php
/** Landing page with the global header and footer. @package DinizStudio */
?>
<main id="dv-main-content" class="dv-landing-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>><?php the_content(); ?></article>
	<?php endwhile; ?>
</main>
