<?php
/**
 * Default editable page content.
 *
 * @package DinizStudio
 */
?>
<main id="dv-main-content">
	<?php while ( have_posts() ) : ?>
		<?php the_post(); ?>
		<section class="wp-block-group alignfull dv-page-hero">
			<div class="wp-block-group alignwide">
				<p class="dv-kicker dv-kicker-dark"><?php esc_html_e( 'Conteúdo', 'dv-visual' ); ?></p>
				<h1 class="has-xxl-font-size"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?><p class="has-l-font-size"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
			</div>
		</section>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'wp-block-group dv-single-wrap' ); ?>>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="wp-block-post-featured-image alignwide"><?php the_post_thumbnail( 'full' ); ?></figure>
			<?php endif; ?>
			<div class="wp-block-post-content"><?php the_content(); ?></div>
			<?php wp_link_pages(); ?>
		</article>
	<?php endwhile; ?>
</main>
