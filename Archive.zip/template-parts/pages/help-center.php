<?php
/** Help center page. @package DinizStudio */
?>
<main id="dv-main-content" class="wp-block-group dv-help-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<section class="wp-block-group alignwide dv-help-intro">
			<p class="dv-kicker"><?php esc_html_e( 'Central de ajuda', 'dv-visual' ); ?></p>
			<h1><?php the_title(); ?></h1>
			<?php get_search_form(); ?>
			<?php if ( trim( get_the_content() ) ) : ?><div class="dv-page-editor-content"><?php the_content(); ?></div><?php endif; ?>
		</section>
	<?php endwhile; ?>
	<section class="dv-page-collections">
		<?php echo diniz_studio_cpt_featured_shortcode( array( 'post_type' => 'help_article', 'limit' => 6, 'kicker' => 'Respostas recentes', 'title' => 'Encontre o que você precisa.' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</section>
	<?php diniz_studio_render_pattern( 'faq' ); ?>
</main>
